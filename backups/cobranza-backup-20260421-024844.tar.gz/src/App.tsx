import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import {
  // Auth
  setPin, verifyPin, isPinSet, isSessionActive, activateSession, resetSession, setLastActivity, isSessionExpired,
  // Audit
  registrarAuditoria, getAuditoria, exportarAuditoria,
  type AuditAction,
  // WhatsApp
  formatearNumeroWhatsApp, generarLinkWhatsApp,
} from './utils/exports';

// ==========================================
// TIPOS
// ==========================================
interface Cliente {
  id: string; nombre: string; telefono: string; direccion: string;
  lat?: number; lng?: number; coordenadaErr?: string;
  saldo: number; quota: number; frecuencia: 'diaria' | 'semanal' | 'quincenal' | 'mensual';
  fechaAlta: string; activo: boolean; ultimaVisita?: string;
  notas?: string; promesaPago?: string; promesaFecha?: string;
  ultimoMontoRecibido?: number;
}
interface Ficha {
  id: string; clienteId: string; tipo: 'venta' | 'prestamo';
  montoTotal: number; precioVenta: number; costo: number; ganancia: number;
  saldo: number; cuotas: number; cuotasPagas: number; cuotaMonto: number;
  fecha: string; estado: 'activa' | 'cancelada' | 'vencida';
  pagos: { fecha: string; monto: number; dia: number; tipo: 'completo' | 'parcial' | 'mora'; observaciones?: string }[];
  Mora: number; moraPorciento: number;
}
interface Gasto { id: string; fecha: string; categoria: string; monto: number; nota: string; userId: string; sync: boolean; timestamp: number; }
interface Cierre { id: string; fecha: string; userId: string; username: string; totalSistema: number; montoFisico: number; diferencia: number; kmFin?: number; novedades: string; validado: boolean; sync: boolean; timestamp: number; }
interface LogEntry { id: string; fecha: string; hora: string; accion: string; usuario: string; detalle: string; }
interface Config { moneda: string; simboloMoneda: string; moraPorciento: number; nombreEmpresa: string; telefonoEmpresa: string; direccionEmpresa: string; ruc: string; numeroWhatsappAdmin: string; }
interface VisitaFallida { clienteId: string; fecha: string; hora: string; motivo: 'no_domicilio' | 'sin_dinero' | 'promesa_pago' | 'local_cerrado'; lat: number; lng: number; observaciones?: string; promesaFecha?: string; }

/** Metadatos guardados en cp_data_v2 (clientes/fichas/gastos van aparte en cp_cli, cp_fic, cp_gas). */
interface AppMeta {
  cierres: Cierre[];
  logs: LogEntry[];
  config: Config;
  cierresJornada: Cierre[];
  visitasFallidas: VisitaFallida[];
}

// ==========================================
// UTILIDADES
// ==========================================
const genId = () => `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
const M: Config = { moneda: 'ARS', simboloMoneda: '$', moraPorciento: 2, nombreEmpresa: 'CobranzaPro ERP', telefonoEmpresa: '+54 11 0000 0000', direccionEmpresa: 'Calle Principal 123', ruc: '00-00000000-0', numeroWhatsappAdmin: '' };

function fmt(n: number) { return `${M.simboloMoneda} ${n.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`; }
function hoy() { return new Date().toISOString().split('T')[0]; }
function addDias(fecha: string, dias: number) {
  const d = new Date(fecha); d.setDate(d.getDate() + dias);
  return d.toISOString().split('T')[0];
}
function diffDias(a: string, b: string) {
  return Math.floor((new Date(a).getTime() - new Date(b).getTime()) / 86400000);
}

const HABILES = [1, 2, 3, 4, 5]; // Lunes a viernes
function proxDiaHabil(fecha: string): string {
  let d = new Date(fecha);
  while (!HABILES.includes(d.getDay())) d.setDate(d.getDate() + 1);
  return d.toISOString().split('T')[0];
}

function generarRecibo(ficha: Ficha, cliente: Cliente): string {
  const id = ficha.id.split('_')[0].toUpperCase();
  const prox = ficha.pagos.find(p => p.tipo === 'mora' || (p.monto < ficha.cuotaMonto && p.monto > 0));
  const proxFecha = prox ? addDias(ficha.fecha, prox.dia) : 'N/A';
  return `RECIBO DIGITAL #${id.slice(-6).toUpperCase()}

${M.nombreEmpresa}

─────────────────────
Cliente: ${cliente.nombre}
Fecha: ${new Date().toLocaleDateString('es-AR')}
─────────────────────

Monto Recibido: ${fmt(ficha.pagos.reduce((s, p) => s + p.monto, 0))}
Saldo Restante: ${fmt(ficha.saldo)}
Próxima Cuota: ${proxFecha}

─────────────────────
¡Gracias por su pago!`;
}

function generarLinkWA(numero: string, mensaje: string): string {
  const limpio = formatearNumeroWhatsApp(numero);
  return generarLinkWhatsApp(limpio, mensaje);
}

class SectionErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch() {
    // Evita que errores de una seccion rompan toda la app.
  }

  handleRetry = () => {
    this.setState({ hasError: false });
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="bg-gray-900/60 border border-red-500/30 rounded-2xl p-4 text-center">
          <p className="text-red-300 font-semibold">Hubo un problema al cargar esta sección. Reintentar</p>
          <button
            onClick={this.handleRetry}
            className="mt-3 px-4 py-2 rounded-xl bg-red-500/20 border border-red-500/40 text-red-200 text-sm font-semibold hover:bg-red-500/30 transition"
          >
            Reintentar
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

// Haversine
function calcularDistancia(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// ==========================================
// INIT DATA (demos solo si no hay nada en localStorage dedicado)
// ==========================================
const FICHAS_DEMO: Ficha[] = [
  { id: genId(), clienteId: 'cli_1', tipo: 'prestamo', montoTotal: 50000, precioVenta: 65000, costo: 50000, ganancia: 15000, saldo: 65000, cuotas: 10, cuotasPagas: 3, cuotaMonto: 6500, fecha: addDias(hoy(), -30), estado: 'activa', pagos: [{ fecha: addDias(hoy(), -21), monto: 6500, dia: 7, tipo: 'completo' }, { fecha: addDias(hoy(), -14), monto: 6500, dia: 14, tipo: 'completo' }, { fecha: addDias(hoy(), -7), monto: 6500, dia: 21, tipo: 'completo' }], Mora: 0, moraPorciento: 2 },
  { id: genId(), clienteId: 'cli_2', tipo: 'prestamo', montoTotal: 30000, precioVenta: 36000, costo: 30000, ganancia: 6000, saldo: 12000, cuotas: 6, cuotasPagas: 4, cuotaMonto: 6000, fecha: addDias(hoy(), -40), estado: 'activa', pagos: [{ fecha: addDias(hoy(), -33), monto: 6000, dia: 7, tipo: 'completo' }, { fecha: addDias(hoy(), -26), monto: 6000, dia: 14, tipo: 'completo' }, { fecha: addDias(hoy(), -19), monto: 6000, dia: 21, tipo: 'completo' }, { fecha: addDias(hoy(), -12), monto: 6000, dia: 28, tipo: 'completo' }], Mora: 0, moraPorciento: 2 },
];
const CLIENTES_DEMO: Cliente[] = [
  { id: 'cli_1', nombre: 'María González', telefono: '5492615551234', direccion: 'Av. Rivadavia 4521, CABA', lat: -34.6037, lng: -58.3816, saldo: 45500, quota: 6500, frecuencia: 'semanal', fechaAlta: addDias(hoy(), -60), activo: true, notas: 'Cliente VIP', promesaPago: '', promesaFecha: '' },
  { id: 'cli_2', nombre: 'Carlos Pérez', telefono: '5491151234567', direccion: 'Calle Florida 234, CABA', lat: -34.6091, lng: -58.3732, saldo: 12000, quota: 6000, frecuencia: 'semanal', fechaAlta: addDias(hoy(), -45), activo: true, notas: 'Siempre paga en tiempo', promesaPago: '', promesaFecha: '' },
  { id: 'cli_3', nombre: 'Ana Martínez', telefono: '5491132345678', direccion: 'Av. Corrientes 1234, CABA', lat: -34.6037, lng: -58.3816, saldo: 25000, quota: 5000, frecuencia: 'quincenal', fechaAlta: addDias(hoy(), -90), activo: true, notas: '', promesaPago: '', promesaFecha: '' },
  { id: 'cli_4', nombre: 'Luis Rodríguez', telefono: '5491163456789', direccion: 'Calle Lavalle 890, CABA', lat: -34.6117, lng: -58.3759, saldo: 0, quota: 8000, frecuencia: 'semanal', fechaAlta: addDias(hoy(), -120), activo: true, notas: 'Premio por buen pagador', promesaPago: '', promesaFecha: '' },
  { id: 'cli_5', nombre: 'Sofia López', telefono: '5491174567890', direccion: 'Av. Santa Fe 1500, CABA', lat: -34.5985, lng: -58.3888, saldo: 33000, quota: 5500, frecuencia: 'semanal', fechaAlta: addDias(hoy(), -30), activo: true, notas: '', promesaPago: '', promesaFecha: '' },
];

function parseCpDataV2(): Record<string, unknown> | null {
  try {
    const stored = localStorage.getItem('cp_data_v2');
    return stored ? (JSON.parse(stored) as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

function getInitData(): AppMeta {
  const d = parseCpDataV2();
  if (d) {
    return {
      cierres: (d.cierres as AppMeta['cierres']) || [],
      logs: (d.logs as AppMeta['logs']) || [],
      config: { ...M, ...((d.config as Config) || {}) },
      cierresJornada: (d.cierresJornada as AppMeta['cierresJornada']) || [],
      visitasFallidas: (d.visitasFallidas as AppMeta['visitasFallidas']) || [],
    };
  }
  return { cierres: [], logs: [], config: { ...M }, cierresJornada: [], visitasFallidas: [] };
}

// ==========================================
// APP
// ==========================================
export default function App() {
  // --- LÓGICA DE PERSISTENCIA PARA DATOS ---
  const cargar = (key: string, def: any) => {
    const data = window.localStorage.getItem(key); // Agregamos 'window.' para más seguridad
    return data ? JSON.parse(data) : def;
  };

  const [clientes, setClientes] = useState<Cliente[]>(() => {
    const v = cargar('cp_cli', [] as Cliente[]);
    if (Array.isArray(v) && v.length) return v;
    const d = parseCpDataV2();
    const leg = d?.clientes as Cliente[] | undefined;
    if (Array.isArray(leg) && leg.length) return leg;
    return CLIENTES_DEMO;
  });
  const [fichas, setFichas] = useState<Ficha[]>(() => {
    const v = cargar('cp_fic', [] as Ficha[]);
    if (Array.isArray(v) && v.length) return v;
    const d = parseCpDataV2();
    const leg = d?.fichas as Ficha[] | undefined;
    if (Array.isArray(leg) && leg.length) return leg;
    return FICHAS_DEMO;
  });
  const [pagos] = useState<any[]>(() => cargar('cp_pag', []));
  const [gastos, setGastos] = useState<Gasto[]>(() => {
    const v = cargar('cp_gas', [] as Gasto[]);
    if (Array.isArray(v) && v.length) return v;
    const d = parseCpDataV2();
    const leg = d?.gastos as Gasto[] | undefined;
    return Array.isArray(leg) ? leg : [];
  });
  const [auditoria] = useState<any[]>(() => cargar('cp_aud', []));

  useEffect(() => {
    localStorage.setItem('cp_cli', JSON.stringify(clientes));
    localStorage.setItem('cp_fic', JSON.stringify(fichas));
    localStorage.setItem('cp_pag', JSON.stringify(pagos));
    localStorage.setItem('cp_gas', JSON.stringify(gastos));
    localStorage.setItem('cp_aud', JSON.stringify(auditoria));
  }, [clientes, fichas, pagos, gastos, auditoria]);
  // -----------------------------------------
  const [data, setData] = useState<AppMeta>(getInitData);
  const { cierresJornada } = data;
  const [user, setUser] = useState<string | null>(localStorage.getItem('cp_session') ? JSON.parse(localStorage.getItem('cp_session')!).username : null);
  const [rol, setRol] = useState<string | null>(localStorage.getItem('cp_session') ? JSON.parse(localStorage.getItem('cp_session')!).rol : null);
  const [page, setPage] = useState<string>('login');
  const [loading, setLoading] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showSplash, setShowSplash] = useState(true);
  const [splashMs, setSplashMs] = useState(0);

  // PIN Lock
  const [locked, setLocked] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');
  const [showPinSetup, setShowPinSetup] = useState(false);

  // Filters & Search
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Modals
  const [mCliente, setMCliente] = useState<Partial<Cliente> | null>(null);
  const [mPago, setMPago] = useState<{ ficha: Ficha; cliente: Cliente } | null>(null);
  const [mFicha, setMFicha] = useState<{ cliente: Cliente; ficha?: Ficha } | null>(null);
  const [mGasto, setMGasto] = useState<Partial<Gasto> | null>(null);
  const [mCierre, setMCierre] = useState<Partial<Cierre> | null>(null);
  const [mJornada, setMJornada] = useState(false);
  const [mNoPago, setMNoPago] = useState<{ ficha: Ficha; cliente: Cliente } | null>(null);
  const [mAuditoria, setMAuditoria] = useState(false);
  const [mDetalleCliente, setMDetalleCliente] = useState<Cliente | null>(null);
  const [mRuta, setMRuta] = useState(false);

  // GPS
  const [gpsLoading, setGpsLoading] = useState(false);
  const [gpsPos, setGpsPos] = useState<{ lat: number; lng: number } | null>(null);

  // Tab state for FichaForm
  const [tab, setTab] = useState(0);

  type SavePatch = Partial<AppMeta> & Partial<{ clientes: Cliente[]; fichas: Ficha[]; gastos: Gasto[] }>;

  const save = useCallback((upd: SavePatch) => {
    if (upd.clientes !== undefined) setClientes(upd.clientes);
    if (upd.fichas !== undefined) setFichas(upd.fichas);
    if (upd.gastos !== undefined) setGastos(upd.gastos);
    const { clientes: _c, fichas: _f, gastos: _g, ...meta } = upd;
    setData(prev => {
      const next = { ...prev, ...meta };
      localStorage.setItem('cp_data_v2', JSON.stringify(next));
      return next;
    });
  }, []);

  // Audit
  const audit = useCallback(( accion: AuditAction, detalle: string, gps?: { lat: number; lng: number } ) => {
    registrarAuditoria(accion, detalle, gps);
  }, []);

  // ==========================================
  // EFFECTS
  // ==========================================
  useEffect(() => {
    const onOnline = () => { setIsOnline(true); audit('SYNC_ONLINE', 'Conexión restaurada'); };
    const onOffline = () => { setIsOnline(false); audit('SYNC_OFFLINE', 'Conexión perdida'); };
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => { window.removeEventListener('online', onOnline); window.removeEventListener('offline', onOffline); };
  }, [audit]);

  useEffect(() => {
    if (!isPinSet() && user) { setShowPinSetup(true); }
    if (user && isPinSet() && !isSessionActive()) { setLocked(true); }
    if (user && isSessionExpired()) { setLocked(true); }
  }, [user]);

  useEffect(() => {
    if (!locked) return;
    const handler = () => setLastActivity();
    window.addEventListener('touchstart', handler);
    window.addEventListener('click', handler);
    window.addEventListener('keydown', handler);
    return () => {
      window.removeEventListener('touchstart', handler);
      window.removeEventListener('click', handler);
      window.removeEventListener('keydown', handler);
    };
  }, [locked]);

  useEffect(() => {
    const t0 = performance.now();
    const timer = window.setInterval(() => {
      const elapsed = Math.min(3000, performance.now() - t0);
      setSplashMs(elapsed);
      if (elapsed >= 3000) {
        setShowSplash(false);
        window.clearInterval(timer);
      }
    }, 16);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    console.log(
      '%c--- CobranzaPro EmD - Propiedad Intelectual de Emanuel Moreno ---',
      'color: #a78bfa; background: #111827; border: 1px solid #374151; padding: 8px 12px; border-radius: 8px; font-weight: 700;'
    );
  }, []);

  // ==========================================
  // COMPUTED
  // ==========================================

  const filtrados = useMemo(() => {
    const status = ['all', 'mora', 'pendiente', 'alDia'].includes(filterStatus) ? filterStatus : 'all';
    const baseClientes = Array.isArray(clientes) ? clientes.filter(c => c && typeof c === 'object') : [];
    let list = [...baseClientes];
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(c =>
        (c?.nombre ?? '').toLowerCase().includes(q)
        || (c?.direccion ?? '').toLowerCase().includes(q)
        || (c?.telefono ?? '').includes(q)
      );
    }
    switch (status) {
      case 'mora':
        list = list.filter(c => (c?.saldo ?? 0) > 0 && (getMoraClientes(c).total ?? 0) > 0);
        break;
      case 'pendiente':
        list = list.filter(c => (c?.saldo ?? 0) > 0 && (getMoraClientes(c).total ?? 0) === 0);
        break;
      case 'alDia':
        list = list.filter(c => (c?.saldo ?? 0) === 0);
        break;
      default:
        // "all": conserva lista completa
        break;
    }
    return list;
  }, [clientes, search, filterStatus]);

  const getFichasCliente = useCallback((id: string) => fichas.filter(f => f.clienteId === id), [fichas]);

  const getMoraClientes = (cliente?: Cliente | null) => {
    try {
      if (!cliente?.id) return { total: 0, diasMora: 0, proxFecha: '' };
      const fs = getFichasCliente(cliente.id);
      let total = 0, diasMora = 0, proxFecha = '';
      const h = hoy();
      fs.filter(f => f?.estado === 'activa').forEach(f => {
        if ((f?.saldo ?? 0) > 0) {
          const pagado = (f?.pagos ?? []).reduce((s, p) => s + (p?.monto ?? 0), 0);
          const esperado = (f?.cuotaMonto ?? 0) * (f?.cuotasPagas ?? 0);
          const diff = Math.max(0, esperado - pagado);
          total += diff + (f?.saldo ?? 0);
        }
      });
      if (total > 0) diasMora = 7;
      const fxs = fs.filter(f => f?.estado === 'activa' && (f?.saldo ?? 0) > 0);
      if (fxs.length > 0) proxFecha = proxDiaHabil(h);
      return { total, diasMora, proxFecha };
    } catch {
      return { total: 0, diasMora: 0, proxFecha: '' };
    }
  };

  const getSemafClient = (cliente?: Cliente | null) => {
    try {
      if (!cliente?.id) return '⚪';
      const { total } = getMoraClientes(cliente);
      const fs = getFichasCliente(cliente.id);
      const h = hoy();
      const tienePagoHoy = fs.some(f => (f?.pagos ?? []).some(p => p?.fecha === h));
      if (total > 0) return '🔴';
      if (tienePagoHoy) return '🟢';
      if ((cliente?.saldo ?? 0) > 0) return '🟡';
      return '⚪';
    } catch {
      return '⚪';
    }
  };

  const getStatusText = (cliente?: Cliente | null) => {
    const sem = getSemafClient(cliente);
    if (sem === '🔴') return 'En Mora';
    if (sem === '🟢') return 'Al Día';
    if (sem === '🟡') return 'Pendiente';
    return 'Sin Deuda';
  };

  // KPIs Dashboard
  const kpis = useMemo(() => {
    const h = hoy();
    const clientesConDeuda = (Array.isArray(clientes) ? clientes : []).filter(c => (c?.saldo ?? 0) > 0);
    const totalMoraRaw = clientesConDeuda.reduce((s, c) => s + (getMoraClientes(c).total || 0), 0);
    const totalMora = Number.isFinite(totalMoraRaw) ? totalMoraRaw : 0;
    const moraClientes = clientesConDeuda.filter(c => getMoraClientes(c).total > 0);

    const cierresHoy = cierresJornada.filter(c => c.fecha === h && c.userId === (user || ''));
    const totalCobradoHoy = cierresHoy.reduce((s, c) => s + c.montoFisico, 0);

    const gastosHoy = gastos.filter(g => g.fecha === h);
    const totalGastosHoy = gastosHoy.reduce((s, g) => s + g.monto, 0);

    const totalEsperado = fichas.reduce((s, f) => {
      if (f.estado !== 'activa') return s;
      return s + (f.cuotaMonto * f.cuotasPagas) + f.pagos.reduce((sp, p) => sp + p.monto, 0);
    }, 0);

    const efectividad = totalEsperado > 0 ? (totalCobradoHoy / totalEsperado) * 100 : 0;
    const gananciaNeta = totalCobradoHoy - totalGastosHoy;

    const promesasCount = (Array.isArray(clientes) ? clientes : []).filter(c => c?.promesaFecha === h).length;

    return { moraClientes: moraClientes.length, totalMora, totalCobradoHoy, totalGastosHoy, efectividad, gananciaNeta, promesasCount, clientesConDeuda: clientesConDeuda.length };
  }, [clientes, fichas, gastos, cierresJornada, user]);

  const cierreDelDia = useMemo(() => {
    return cierresJornada.find(c => c.fecha === hoy() && c.userId === user);
  }, [cierresJornada, user]);

  const jornadaActiva = useMemo(() => {
    if (!cierreDelDia) return false;
    return cierresJornada.some(c => c.fecha === hoy() && c.userId === user && !c.validado);
  }, [cierreDelDia, cierresJornada, user]);

  const rankingCobradores = useMemo(() => {
    const map: { [k: string]: { username: string; total: number; cierres: number } } = {};
    cierresJornada.forEach(c => {
      if (!map[c.userId]) map[c.userId] = { username: c.username, total: 0, cierres: 0 };
      map[c.userId].total += c.montoFisico;
      map[c.userId].cierres += 1;
    });
    return Object.values(map).sort((a, b) => b.total - a.total);
  }, [cierresJornada]);

  // Proyeccion 7 dias
  const proyeccion7d = useMemo(() => {
    const dias = [];
    for (let i = 0; i < 7; i++) {
      const fecha = addDias(hoy(), i);
      const total = fichas.reduce((s, f) => {
        if (f.estado !== 'activa') return s;
        return s + f.cuotaMonto;
      }, 0);
      dias.push({ fecha, total });
    }
    return dias;
  }, [fichas]);

  // ==========================================
  // GPS
  // ==========================================
  const getGPS = (): Promise<{ lat: number; lng: number }> => {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) { reject(new Error('Geolocalización no disponible')); return; }
      setGpsLoading(true);
      navigator.geolocation.getCurrentPosition(
        pos => { setGpsPos({ lat: pos.coords.latitude, lng: pos.coords.longitude }); setGpsLoading(false); resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }); },
        err => { setGpsLoading(false); reject(err); },
        { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
      );
    });
  };

  // ==========================================
  // LOGIN
  // ==========================================
  const doLogin = (username: string, password: string) => {
    setLoading(true);
    setTimeout(() => {
      const creds: { [k: string]: { pw: string; rol: string } } = {
        super: { pw: 'super123', rol: 'super' }, admin: { pw: 'admin123', rol: 'admin' },
        cobrador: { pw: 'cobrador123', rol: 'cobrador' },
      };
      const c = creds[username.toLowerCase()];
      if (c && c.pw === password) {
        const u = { username, rol: c.rol };
        localStorage.setItem('cp_session', JSON.stringify(u));
        setUser(username); setRol(c.rol); setPage('dashboard'); activateSession();
        audit('LOGIN_SUCCESS', `Login exitoso: ${username}`);
      } else {
        audit('LOGIN_FAILED', `Login fallido: ${username}`);
        alert('Credenciales incorrectas');
      }
      setLoading(false);
    }, 600);
  };

  const doLogout = () => {
    resetSession();
    setUser(null); setRol(null); setPage('login');
    audit('LOGOUT', `Logout: ${user}`);
  };

  // ==========================================
  // PIN
  // ==========================================
  const handlePinDigit = (d: string) => {
    if (pinInput.length < 4) {
      const next = pinInput + d;
      setPinInput(next);
      if (next.length === 4) {
        if (showPinSetup) { setPin(next); setShowPinSetup(false); setLocked(false); setPinInput(''); activateSession(); audit('PIN_CAMBIO', 'PIN configurado'); }
        else if (verifyPin(next)) { setLocked(false); setPinInput(''); activateSession(); }
        else { setPinError('PIN incorrecto'); setPinInput(''); setTimeout(() => setPinError(''), 2000); }
      }
    }
  };

  const handlePinBorrar = () => setPinInput(p => p.slice(0, -1));

  // ==========================================
  // CLIENTES
  // ==========================================
  const handleSaveCliente = (cli: Partial<Cliente>) => {
    if (!cli.nombre || !cli.telefono) { alert('Nombre y teléfono son obligatorios'); return; }
    if (cli.id) {
      save({ clientes: clientes.map(c => c.id === cli.id ? { ...c, ...cli } : c) });
      audit('CLIENTE_EDITADO', `Cliente editado: ${cli.nombre}`, gpsPos || undefined);
    } else {
      const nuevo: Cliente = { id: genId(), nombre: cli.nombre!, telefono: cli.telefono!, direccion: cli.direccion || '', lat: cli.lat, lng: cli.lng, saldo: 0, quota: cli.quota || 0, frecuencia: cli.frecuencia || 'semanal', fechaAlta: hoy(), activo: true, notas: '', promesaPago: '', promesaFecha: '' };
      save({ clientes: [...clientes, nuevo] });
      audit('CLIENTE_CREADO', `Cliente creado: ${nuevo.nombre}`, gpsPos || undefined);
    }
    setMCliente(null);
  };

  const handleDeleteCliente = (id: string) => {
    if (confirm('¿Eliminar cliente?')) {
      save({ clientes: clientes.filter(c => c.id !== id), fichas: fichas.filter(f => f.clienteId !== id) });
      audit('CLIENTE_ELIMINADO', `Cliente eliminado ID: ${id}`);
    }
  };

  // Geolocalizar cliente
  const geoCliente = (cli: Cliente) => {
    if (cli.lat && cli.lng) { window.open(`https://www.google.com/maps?q=${cli.lat},${cli.lng}`, '_blank'); }
    else if (cli.direccion) { window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(cli.direccion)}`, '_blank'); }
  };

  const waCliente = (cli: Cliente) => {
    const tel = formatearNumeroWhatsApp(cli.telefono);
    window.open(generarLinkWhatsApp(tel, `Hola ${cli.nombre}, te contactamos desde ${M.nombreEmpresa}. Tu saldo pendiente es ${fmt(cli.saldo)}.`), '_blank');
  };

  // ==========================================
  // FICHAS
  // ==========================================
  const handleSaveFicha = (fic: Partial<Ficha>) => {
    if (!fic.clienteId || !fic.montoTotal) { alert('Datos incompletos'); return; }
    const cli = clientes.find(c => c.id === fic.clienteId);
    if (!cli) return;
    const pv = fic.precioVenta || fic.montoTotal;
    const costo = fic.costo || fic.montoTotal;
    const ganancia = pv - costo;
    if (fic.id) {
      save({ fichas: fichas.map(f => f.id === fic.id ? { ...f, ...fic } : f) });
    } else {
      const nueva: Ficha = { id: genId(), clienteId: fic.clienteId, tipo: fic.tipo || 'venta', montoTotal: fic.montoTotal, precioVenta: pv, costo, ganancia, saldo: pv, cuotas: fic.cuotas || 1, cuotasPagas: 0, cuotaMonto: (pv / (fic.cuotas || 1)), fecha: hoy(), estado: 'activa', pagos: [], Mora: 0, moraPorciento: M.moraPorciento };
      save({ fichas: [...fichas, nueva] });
      audit('FICHA_CREADA', `Ficha creada para ${cli.nombre}: ${fmt(pv)}`, gpsPos || undefined);
    }
    setMFicha(null);
  };

  const handleDeleteFicha = (id: string) => {
    if (confirm('Eliminar esta ficha?')) {
      save({ fichas: fichas.filter(f => f.id !== id) });
    }
  };

  // ==========================================
  // PAGOS
  // ==========================================
  const handlePago = ( ficha: Ficha, cliente: Cliente, monto: number, observaciones: string ) => {
    if (monto <= 0) { alert('Ingresá un monto'); return; }
    const gps = gpsPos || null;
    const tipo: 'completo' | 'parcial' = monto >= ficha.cuotaMonto ? 'completo' : 'parcial';
    const moraCalc = ficha.Mora;

    const nuevoPago = { fecha: hoy(), monto, dia: diffDias(hoy(), ficha.fecha), tipo, observaciones, gps };
    const pagosActualizados = [...ficha.pagos, nuevoPago];
    const totalPagado = pagosActualizados.reduce((s, p) => s + p.monto, 0);
    const nuevoSaldo = Math.max(0, ficha.precioVenta - totalPagado);

    let MoraActualizada = moraCalc;
    if (tipo === 'parcial') {
      const faltante = ficha.cuotaMonto - monto;
      MoraActualizada += faltante;
    }

    const cuotasPagas = tipo === 'completo' ? ficha.cuotasPagas + 1 : ficha.cuotasPagas;

    const fichaActualizada: Ficha = {
      ...ficha, saldo: nuevoSaldo, Mora: MoraActualizada, pagos: pagosActualizados, cuotasPagas,
      estado: nuevoSaldo === 0 ? 'cancelada' : 'activa',
    };

    save({ fichas: fichas.map(f => f.id === ficha.id ? fichaActualizada : f) });
    save({ clientes: clientes.map(c => c.id === cliente.id ? { ...c, saldo: cliente.saldo - monto + MoraActualizada, ultimaVisita: hoy(), ultimoMontoRecibido: monto } : c) });

    audit('PAGO_REGISTRADO', `Pago de ${fmt(monto)} - Cliente: ${cliente.nombre} - Tipo: ${tipo}`, gps ?? undefined);

    // WhatsApp Receipt
    const recibo = generarRecibo(fichaActualizada, cliente);
    const linkWA = generarLinkWA(cliente.telefono, encodeURIComponent(recibo));
    if (confirm('¿Enviar comprobante por WhatsApp?')) { window.open(linkWA, '_blank'); }

    setMPago(null); setGpsPos(null);
  };

  const handleEliminarPago = ( ficha: Ficha, idx: number ) => {
    if (!confirm('Eliminar este pago?')) return;
    const pagosActualizados = ficha.pagos.filter((_, i) => i !== idx);
    const totalPagado = pagosActualizados.reduce((s, p) => s + p.monto, 0);
    const nuevoSaldo = Math.max(0, ficha.precioVenta - totalPagado);
    save({ fichas: fichas.map(f => f.id === ficha.id ? { ...f, pagos: pagosActualizados, saldo: nuevoSaldo, cuotasPagas: pagosActualizados.filter(p => p.tipo === 'completo').length } : f) });
    audit('PAGO_ELIMINADO', `Pago eliminado - Ficha ID: ${ficha.id}`);
  };

  // ==========================================
  // NO PAGO / VISITA FALLIDA
  // ==========================================
  const handleNoPago = ( _ficha: Ficha, cliente: Cliente, motivo: string, obs: string, promesaFecha: string ) => {
    if (!gpsPos) { alert('GPS obligatorio. Permití el acceso a ubicación.'); return; }
    const vf: VisitaFallida = { clienteId: cliente.id, fecha: hoy(), hora: new Date().toLocaleTimeString('es-AR'), motivo: motivo as any, lat: gpsPos.lat, lng: gpsPos.lng, observaciones: obs, promesaFecha };
    save({ visitasFallidas: [...(data.visitasFallidas || []), vf] });
    if (cliente.promesaFecha !== promesaFecha) {
      save({ clientes: clientes.map(c => c.id === cliente.id ? { ...c, promesaFecha, promesaPago: obs } : c) });
    }
    audit('VISITA_FALLIDA', `Visita fallida: ${cliente.nombre} - Motivo: ${motivo}`, gpsPos ?? undefined);
    setMNoPago(null); setGpsPos(null);
  };

  // ==========================================
  // GASTOS
  // ==========================================
  const handleSaveGasto = (g: Partial<Gasto>) => {
    if (!g.monto || g.monto <= 0) { alert('Monto inválido'); return; }
    const nuevo: Gasto = { id: genId(), fecha: hoy(), categoria: g.categoria || 'Otros', monto: g.monto, nota: g.nota || '', userId: user || '', sync: isOnline, timestamp: Date.now() };
    save({ gastos: [...gastos, nuevo] });
    audit('GASTO_CREADO', `Gasto registrado: ${fmt(g.monto)} - ${g.categoria}`);
    setMGasto(null);
  };

  const handleDeleteGasto = (id: string) => {
    if (confirm('Eliminar gasto?')) { save({ gastos: gastos.filter(g => g.id !== id) }); audit('GASTO_ELIMINADO', `Gasto eliminado ID: ${id}`); }
  };

  // ==========================================
  // CIERRE DE JORNADA
  // ==========================================
  const handleCierreJornada = (montoFisico: number, kmFin?: number, novedades: string = '') => {
    const gps = gpsPos || undefined;
    const totalSistema = kpis.totalCobradoHoy;
    const diferencia = montoFisico - totalSistema;

    const cierre: Cierre = { id: genId(), fecha: hoy(), userId: user || '', username: user || '', totalSistema, montoFisico, diferencia, kmFin, novedades, validado: false, sync: false, timestamp: Date.now() };
    save({ cierresJornada: [...cierresJornada, cierre] });
    audit('CIERRE_JORNADA', `Cierre jornada - Sistema: ${fmt(totalSistema)} | Físico: ${fmt(montoFisico)} | Diferencia: ${fmt(diferencia)}`, gps);

    // WhatsApp Reporte
    const diffSigno = diferencia >= 0 ? `+${fmt(diferencia)}` : fmt(diferencia);
    const tipoDiff = diferencia > 0 ? '💚 Sobrante' : diferencia < 0 ? '🚩 Faltante' : '✅ Cuadrado';
    const msg = `🚩 REPORTE DE CIERRE - ${user}

📅 Fecha: ${hoy()}
👤 Cobrador: ${user}

💰 Total Sistema: ${fmt(totalSistema)}
💵 Efectivo Declarado: ${fmt(montoFisico)}
📊 Diferencia: ${diffSigno} ${tipoDiff}

📝 Novedades: ${novedades || 'Sin novedades'}

_${M.nombreEmpresa}_`;

    const adminNum = formatearNumeroWhatsApp(M.numeroWhatsappAdmin || M.telefonoEmpresa);
    const linkWA = generarLinkWhatsApp(adminNum, encodeURIComponent(msg));

    setMCierre(cierre);
    setMJornada(false);

    if (confirm('✅ Jornada cerrada. ¿Enviar reporte al Administrador por WhatsApp?')) {
      window.open(linkWA, '_blank');
    }
  };

  // ==========================================
  // RUTA INTELIGENTE
  // ==========================================
  const [clientesOrdenados, setClientesOrdenados] = useState<(Cliente & { distancia: number })[]>([]);
  const [ordenandoRuta, setOrdenandoRuta] = useState(false);

  const optimizarRuta = async () => {
    if (!navigator.geolocation) { alert('Geolocalización no disponible'); return; }
    setOrdenandoRuta(true);
    try {
      const pos = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, { enableHighAccuracy: true, timeout: 10000 });
      });
      const { latitude: latU, longitude: lngU } = pos.coords;
      const pendientes = clientes.filter(c => c.saldo > 0 && c.lat && c.lng);
      const conDist = pendientes.map(c => ({
        ...c, distancia: calcularDistancia(latU, lngU, c.lat!, c.lng!),
      })).sort((a, b) => a.distancia - b.distancia);
      setClientesOrdenados(conDist);
      setMRuta(true);
    } catch (e) {
      alert('No se pudo obtener ubicación. Asegurate de permitir GPS.');
    }
    setOrdenandoRuta(false);
  };

  // ==========================================
  // MODAL: GPS PARA ACCIONES
  // ==========================================
  const capturarGPSAccion = async (accion: 'pago' | 'nopago') => {
    try {
      await getGPS();
      if (accion === 'pago') setMPago(mPago ? { ...mPago } : null);
      else setMNoPago(mNoPago ? { ...mNoPago } : null);
    } catch {
      alert('GPS obligatorio. Por favor permití el acceso a tu ubicación.');
    }
  };

  // ==========================================
  // SWIPE
  // ==========================================
  const [swiped, setSwiped] = useState<string | null>(null);

  const SwipeRow = ({ id, children, onEdit, onDelete, onDetail }: { id: string; children: React.ReactNode; onEdit?: () => void; onDelete?: () => void; onDetail?: () => void }) => {
    const startX = useRef(0);
    const onTouchStart = (e: React.TouchEvent) => { startX.current = e.touches[0].clientX; setSwiped(null); };
    const onTouchMove = (e: React.TouchEvent) => {
      const diff = e.touches[0].clientX - startX.current;
      if (Math.abs(diff) > 80) { setSwiped(diff < 0 ? id : null); }
    };
    const onTouchEnd = () => { if (swiped === id) setSwiped(null); };
    return (
      <div className={`relative overflow-hidden rounded-2xl ${swiped === id ? 'shadow-lg' : ''}`}
        onTouchStart={onTouchStart} onTouchMove={onTouchMove} onTouchEnd={onTouchEnd}>
        {swiped === id && (
          <div className="absolute inset-y-0 right-0 flex">
            {onDetail && <button onClick={onDetail} className="w-16 bg-blue-500 text-white flex items-center justify-center active:scale-95 transition">📋</button>}
            {onEdit && <button onClick={onEdit} className="w-16 bg-amber-500 text-white flex items-center justify-center active:scale-95 transition">✏️</button>}
            {onDelete && <button onClick={onDelete} className="w-16 bg-red-500 text-white flex items-center justify-center active:scale-95 transition">🗑️</button>}
          </div>
        )}
        <div className={`transition-transform ${swiped === id ? '-translate-x-20' : ''}`}>{children}</div>
      </div>
    );
  };

  // ==========================================
  // RENDER: LOCK SCREEN
  // ==========================================
  if (showSplash) {
    return <SplashScreen elapsedMs={splashMs} />;
  }

  if (locked || showPinSetup) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex flex-col items-center justify-center p-6">
        <div className="w-full max-w-xs">
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-indigo-500/30">
              <span className="text-3xl">🔐</span>
            </div>
            <h1 className="text-white text-2xl font-bold">{M.nombreEmpresa}</h1>
            <p className="text-gray-400 text-sm mt-1">{showPinSetup ? 'Configurá tu PIN de 4 dígitos' : 'Ingresá tu PIN'}</p>
          </div>
          {/* PIN dots */}
          <div className="flex justify-center gap-4 mb-8">
            {[0,1,2,3].map(i => (
              <div key={i} className={`w-4 h-4 rounded-full transition-all ${i < pinInput.length ? 'bg-indigo-500 scale-125' : 'bg-gray-700'}`} />
            ))}
          </div>
          {pinError && <p className="text-center text-red-400 text-sm mb-4 animate-pulse">{pinError}</p>}
          {/* Keypad */}
          <div className="grid grid-cols-3 gap-3">
            {['1','2','3','4','5','6','7','8','9','','0','⌫'].map((d, i) => (
              <button key={i} onClick={() => d === '⌫' ? handlePinBorrar() : d ? handlePinDigit(d) : null}
                className={`h-14 rounded-2xl text-xl font-semibold transition-all active:scale-90 ${d ? 'bg-gray-800 text-white hover:bg-gray-700 active:bg-indigo-600' : 'bg-transparent'}`}
                disabled={!d}>
                {d === '⌫' ? '⌫' : d}
              </button>
            ))}
          </div>
          {!showPinSetup && (
            <button onClick={() => { setLocked(false); setShowPinSetup(true); setPinInput(''); }}
              className="mt-6 text-gray-400 text-sm w-full text-center hover:text-white transition">
              ¿Olvidaste tu PIN? Reiniciar sesión
            </button>
          )}
        </div>
      </div>
    );
  }

  // ==========================================
  // LOGIN
  // ==========================================
  if (page === 'login') {
    return (
      <div className="min-h-screen bg-gray-950 flex flex-col items-center justify-center p-6">
        <style>{`
          @keyframes loginFadeIn {
            0% { opacity: 0; transform: translateY(8px); }
            100% { opacity: 1; transform: translateY(0); }
          }
          @keyframes loginTextSweep {
            0% { background-position: -220% 0; opacity: 0.25; }
            30% { opacity: 1; }
            100% { background-position: 220% 0; opacity: 1; }
          }
        `}</style>
        <div className="w-full max-w-sm">
          <div className="text-center mb-10" style={{ animation: 'loginFadeIn 0.45s ease-out forwards' }}>
            <div className="w-24 h-24 flex items-center justify-center mx-auto mb-5">
              <span className="text-7xl font-semibold leading-none text-transparent bg-clip-text bg-gradient-to-b from-yellow-200 via-amber-400 to-amber-600 drop-shadow-[0_0_14px_rgba(251,191,36,0.45)]">$</span>
            </div>
            <p
              className="font-medium tracking-widest text-base text-transparent bg-clip-text mx-auto w-fit"
              style={{
                backgroundImage: 'linear-gradient(100deg, #6b7280 20%, #ffffff 45%, #e5e7eb 55%, #6b7280 80%)',
                backgroundSize: '220% 100%',
                animation: 'loginTextSweep 0.9s ease-out 1 forwards',
              }}
            >
              EmD SOFTWARE
            </p>
          </div>
          <LoginForm onLogin={doLogin} loading={loading} />
        </div>
      </div>
    );
  }

  // ==========================================
  // MAIN APP
  // ==========================================
  const go = (p: string) => {
    setPage(p); setSwiped(null); setSearch(''); setFilterStatus('all');
  };

  return (
    <div className="min-h-screen bg-gray-950 text-white font-sans">
      {/* Status Bar */}
      <div className="sticky top-0 z-50 bg-gray-950/90 backdrop-blur-xl border-b border-gray-800">
        <div className="flex items-center justify-between px-4 py-2">
          <div className="flex items-center gap-2">
            <span className="text-lg">💰</span>
            <span className="font-bold text-sm">{M.nombreEmpresa}</span>
          </div>
          <div className="flex items-center gap-2">
            {!isOnline && <span className="text-xs bg-red-500/20 text-red-400 px-2 py-0.5 rounded-full">📴 Offline</span>}
            {(gastos.filter(g => !g.sync).length) > 0 && <span className="text-xs bg-amber-500/20 text-amber-400 px-2 py-0.5 rounded-full">⏳ {gastos.filter(g => !g.sync).length}</span>}
            <span className="text-xs text-gray-500">{new Date().toLocaleDateString('es-AR')}</span>
          </div>
        </div>
        {/* Global Search */}
        {(page === 'dashboard' || page === 'clientes' || page === 'fichas') && (
          <div className="px-4 pb-2">
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">🔍</span>
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar cliente por nombre o dirección..."
                className="w-full bg-gray-800/60 border border-gray-700 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 transition" />
            </div>
          </div>
        )}
      </div>

      {/* Page Content */}
      <main className="pb-24 px-4 pt-3">
        {/* DASHBOARD */}
        {page === 'dashboard' && (
          <div className="space-y-4">
            {/* KPI Cards */}
            <SectionErrorBoundary>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: 'En Mora', valor: kpis.moraClientes, icon: '🚩', color: 'from-red-500/20 to-red-600/10 border-red-500/30', textColor: 'text-red-400', onClick: () => { setFilterStatus('mora'); go('clientes'); } },
                  { label: 'Cobrado Hoy', valor: fmt(kpis.totalCobradoHoy), icon: '💵', color: 'from-green-500/20 to-green-600/10 border-green-500/30', textColor: 'text-green-400', onClick: () => {} },
                  { label: 'Gastos Hoy', valor: fmt(kpis.totalGastosHoy), icon: '📤', color: 'from-orange-500/20 to-orange-600/10 border-orange-500/30', textColor: 'text-orange-400', onClick: () => go('gastos') },
                  { label: 'Efectividad', valor: `${kpis.efectividad.toFixed(0)}%`, icon: '📊', color: 'from-blue-500/20 to-blue-600/10 border-blue-500/30', textColor: 'text-blue-400', onClick: () => go('kpis') },
                ].map((k, i) => (
                  <button key={i} onClick={k.onClick} className={`bg-gradient-to-br ${k.color} border rounded-2xl p-4 text-left active:scale-95 transition-all`}>
                    <div className="flex items-start justify-between">
                      <span className="text-2xl">{k.icon}</span>
                      <span className={`text-xs ${k.textColor} font-medium`}>{k.label}</span>
                    </div>
                    <p className={`text-2xl font-bold mt-2 ${k.textColor}`}>{k.valor}</p>
                  </button>
                ))}
              </div>
            </SectionErrorBoundary>

            {/* Promesas de Pago */}
            {kpis.promesasCount > 0 && (
              <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-4">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">⏰</span>
                  <div>
                    <p className="text-amber-400 font-semibold">Promesas de Pago para Hoy</p>
                    <p className="text-amber-300/70 text-sm">{kpis.promesasCount} cliente(s) tienen compromiso pendiente</p>
                  </div>
                </div>
              </div>
            )}

            {/* Quick Actions */}
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: 'Registrar Cobro', icon: '💵', color: 'bg-green-500', route: 'clientes' },
                { label: 'Ruta del Día', icon: '🗺️', color: 'bg-blue-500', route: 'clientes' },
                { label: 'Lista Morosos', icon: '🚩', color: 'bg-red-500', route: 'clientes' },
                { label: 'Gastos y Caja', icon: '📤', color: 'bg-orange-500', route: 'gastos' },
              ].map((btn, i) => (
                <button key={i} onClick={() => {
                  if (btn.route === 'clientes') setFilterStatus('mora');
                  go(btn.route);
                }}
                  className={`${btn.color} rounded-2xl p-4 flex flex-col items-center gap-2 active:scale-95 transition-all shadow-lg`}>
                  <span className="text-3xl">{btn.icon}</span>
                  <span className="text-white font-semibold text-sm text-center">{btn.label}</span>
                </button>
              ))}
            </div>

            {/* Cierre Jornada */}
            {!jornadaActiva ? (
              <button onClick={() => setMJornada(true)}
                className="w-full bg-gray-800 border border-gray-700 hover:border-indigo-500 rounded-2xl p-4 flex items-center gap-4 active:scale-[0.98] transition-all">
                <div className="w-12 h-12 bg-indigo-500/20 rounded-xl flex items-center justify-center">
                  <span className="text-2xl">🏁</span>
                </div>
                <div className="text-left flex-1">
                  <p className="text-white font-semibold">Finalizar Jornada</p>
                  <p className="text-gray-400 text-xs">Cerrar y enviar reporte</p>
                </div>
                <span className="text-gray-500">→</span>
              </button>
            ) : (
              <div className="bg-green-500/10 border border-green-500/30 rounded-2xl p-4">
                <p className="text-green-400 font-semibold text-center">✅ Jornada Finalizada</p>
                <p className="text-green-300/60 text-xs text-center mt-1">Los cobros están bloqueados hasta mañana</p>
              </div>
            )}

            {/* Recent Activity */}
            <div className="bg-gray-900/60 border border-gray-800 rounded-2xl p-4">
              <h3 className="font-bold text-sm text-gray-300 mb-3">Actividad Reciente</h3>
              <div className="space-y-2">
                {getAuditoria().slice(0, 5).map(e => (
                  <div key={e.id} className="flex items-center gap-3 py-2 border-b border-gray-800/50 last:border-0">
                    <span className="text-xs text-gray-500 w-16">{e.hora}</span>
                    <span className="text-xs text-gray-300 flex-1">{e.detalle}</span>
                  </div>
                ))}
                {getAuditoria().length === 0 && <p className="text-gray-500 text-xs text-center">Sin actividad reciente</p>}
              </div>
            </div>
          </div>
        )}

        {/* CLIENTES */}
        {page === 'clientes' && (
          <div className="space-y-3">
            {/* Filtros */}
            <div className="flex gap-2 overflow-x-auto pb-1 -mx-4 px-4">
              {[{ k: 'all', l: 'Todos' }, { k: 'mora', l: '🔴 Mora' }, { k: 'pendiente', l: '🟡 Pendiente' }, { k: 'alDia', l: '🟢 Al Día' }].map(f => (
                <button key={f.k} onClick={() => { console.log('Cambiando filtro a:', f.k); setFilterStatus(f.k); }}
                  className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${filterStatus === f.k ? 'bg-indigo-500 text-white' : 'bg-gray-800 text-gray-400'}`}>
                  {f.l}
                </button>
              ))}
            </div>

            {/* GPS Ordenar */}
            <button onClick={optimizarRuta} disabled={ordenandoRuta}
              className="w-full bg-blue-500/10 border border-blue-500/30 text-blue-400 rounded-xl py-3 text-sm font-semibold flex items-center justify-center gap-2 active:scale-95 transition">
              {ordenandoRuta ? '⏳ Obteniendo ubicación...' : '📍 Optimizar Ruta (ordenar por distancia)'}
            </button>

            {/* Lista */}
            <SectionErrorBoundary>
              <>
                {filtrados.length === 0 && (
                  <div className="text-center py-12 text-gray-500">
                    <p className="text-4xl mb-3">🔍</p>
                    <p>No se encontraron clientes</p>
                  </div>
                )}
                {filtrados.map(cli => {
                  if (!cli) return null;
                  const { total: moraTotal } = getMoraClientes(cli);
                  const sem = getSemafClient(cli);
                  return (
                    <SwipeRow key={cli.id} id={cli.id}
                      onEdit={() => { setMCliente(cli); setTab(0); }}
                      onDelete={() => handleDeleteCliente(cli.id)}
                      onDetail={() => setMDetalleCliente(cli)}>
                      <button onClick={() => setMDetalleCliente(cli)}
                        className="w-full bg-gray-900/70 border border-gray-800 rounded-2xl p-4 text-left active:scale-[0.98] transition-all">
                        <div className="flex items-start gap-3">
                          <div className="w-12 h-12 bg-gray-800 rounded-xl flex items-center justify-center text-xl flex-shrink-0">
                            {sem === '🔴' ? '🚩' : sem === '🟢' ? '✅' : sem === '🟡' ? '⏳' : '💚'}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="font-bold text-white truncate">{cli.nombre}</p>
                              {cli.promesaFecha && cli.promesaFecha === hoy() && <span className="text-xs bg-amber-500/20 text-amber-400 px-2 py-0.5 rounded-full">⏰ Hoy</span>}
                            </div>
                            <p className="text-gray-400 text-xs truncate">{cli.direccion}</p>
                            <div className="flex items-center gap-3 mt-2">
                              <span className={`text-xs font-semibold ${moraTotal > 0 ? 'text-red-400' : cli.saldo > 0 ? 'text-amber-400' : 'text-green-400'}`}>
                                {fmt(cli.saldo)}
                              </span>
                              <span className="text-xs text-gray-500">Cuota: {fmt(cli.quota)}</span>
                            </div>
                          </div>
                          <div className="flex flex-col gap-2 flex-shrink-0">
                            <button onClick={e => { e.stopPropagation(); waCliente(cli); }} className="w-9 h-9 bg-green-500/20 rounded-lg flex items-center justify-center text-green-400 active:scale-90 transition">💬</button>
                            <button onClick={e => { e.stopPropagation(); geoCliente(cli); }} className="w-9 h-9 bg-blue-500/20 rounded-lg flex items-center justify-center text-blue-400 active:scale-90 transition">📍</button>
                          </div>
                        </div>
                      </button>
                    </SwipeRow>
                  );
                })}
              </>
            </SectionErrorBoundary>

            {(rol === 'super' || rol === 'admin') && (
              <button onClick={() => { setMCliente({}); setTab(0); }}
                className="w-full bg-indigo-500 text-white rounded-2xl py-4 font-bold text-base flex items-center justify-center gap-2 active:scale-95 transition-all shadow-lg shadow-indigo-500/30">
                + Nuevo Cliente
              </button>
            )}
          </div>
        )}

        {/* FICHAS */}
        {page === 'fichas' && (
          <div className="space-y-3">
            {fichas.length === 0 && <div className="text-center py-12 text-gray-500"><p className="text-4xl mb-3">📋</p><p>Sin fichas activas</p></div>}
            {fichas.map(fic => {
              const cli = clientes.find(c => c.id === fic.clienteId);
              if (!cli) return null;
              return (
                <SwipeRow key={fic.id} id={fic.id}
                  onEdit={() => { setMFicha({ cliente: cli, ficha: fic }); setTab(0); }}
                  onDelete={() => handleDeleteFicha(fic.id)}>
                  <button onClick={() => setMFicha({ cliente: cli, ficha: fic })}
                    className="w-full bg-gray-900/70 border border-gray-800 rounded-2xl p-4 text-left active:scale-[0.98] transition-all">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-bold">{cli.nombre}</p>
                        <p className="text-xs text-gray-400">{fic.tipo === 'prestamo' ? '💳 Préstamo' : '🛒 Venta'} · {fic.cuotasPagas}/{fic.cuotas} cuotas</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-indigo-400">{fmt(fic.saldo)}</p>
                        <p className="text-xs text-gray-500">Saldo</p>
                      </div>
                    </div>
                    {/* Barra de progreso */}
                    <div className="mt-3 bg-gray-800 rounded-full h-2">
                      <div className="bg-gradient-to-r from-green-400 to-emerald-500 h-2 rounded-full transition-all" style={{ width: `${(fic.cuotasPagas / fic.cuotas) * 100}%` }} />
                    </div>
                  </button>
                </SwipeRow>
              );
            })}
            {(rol === 'super' || rol === 'admin') && (
              <button onClick={() => { const first = clientes[0]; setMFicha({ cliente: first || null as unknown as Cliente }); setTab(0); setTimeout(() => (document.getElementById('selCliente') as HTMLSelectElement)?.focus(), 100); }}
                className="w-full bg-indigo-500 text-white rounded-2xl py-4 font-bold flex items-center justify-center gap-2 active:scale-95 transition-all">
                + Nueva Ficha
              </button>
            )}
          </div>
        )}

        {/* GASTOS */}
        {page === 'gastos' && (
          <div className="space-y-3">
            {/* Resumen */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-gray-900/60 border border-gray-800 rounded-2xl p-4 text-center">
                <p className="text-xs text-gray-400">Gastos Mes</p>
                <p className="text-xl font-bold text-red-400">{fmt(gastos.reduce((s, g) => s + g.monto, 0))}</p>
              </div>
              <div className="bg-gray-900/60 border border-gray-800 rounded-2xl p-4 text-center">
                <p className="text-xs text-gray-400">Ganancia Neta</p>
                <p className="text-xl font-bold text-green-400">{fmt(kpis.totalCobradoHoy - kpis.totalGastosHoy)}</p>
              </div>
            </div>

            <button onClick={() => setMGasto({})}
              className="w-full bg-orange-500 text-white rounded-2xl py-4 font-bold flex items-center justify-center gap-2 active:scale-95 transition-all">
              + Registrar Gasto
            </button>

            {gastos.filter(g => g.fecha === hoy()).map(g => (
              <div key={g.id} className="bg-gray-900/60 border border-gray-800 rounded-2xl p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{g.categoria === 'Combustible' ? '⛽' : g.categoria === 'Comida' ? '🍔' : g.categoria === 'Reparaciones' ? '🔧' : '📦'}</span>
                  <div>
                    <p className="font-semibold text-sm">{g.categoria}</p>
                    <p className="text-xs text-gray-400">{g.nota || g.fecha}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-bold text-red-400">{fmt(g.monto)}</span>
                  {(rol === 'super' || rol === 'admin') && (
                    <button onClick={() => handleDeleteGasto(g.id)} className="text-red-400/60 text-xs">🗑️</button>
                  )}
                </div>
              </div>
            ))}
            {gastos.filter(g => g.fecha === hoy()).length === 0 && <div className="text-center py-8 text-gray-500 text-sm">Sin gastos hoy</div>}
          </div>
        )}

        {/* KPIs */}
        {page === 'kpis' && (rol === 'super' || rol === 'admin') && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold">📊 Analítica de Negocio</h2>

            {/* Efectividad */}
            <div className="bg-gray-900/60 border border-gray-800 rounded-2xl p-4">
              <p className="text-sm text-gray-400 mb-2">Efectividad de Cobro</p>
              <div className="flex items-end gap-3">
                <span className="text-3xl font-bold text-indigo-400">{kpis.efectividad.toFixed(1)}%</span>
                <div className="flex-1 bg-gray-800 rounded-full h-3 mb-1">
                  <div className="bg-gradient-to-r from-green-400 to-emerald-500 h-3 rounded-full" style={{ width: `${Math.min(100, kpis.efectividad)}%` }} />
                </div>
              </div>
            </div>

            {/* Ranking */}
            <div className="bg-gray-900/60 border border-gray-800 rounded-2xl p-4">
              <p className="text-sm text-gray-400 mb-3">Ranking de Cobradores</p>
              {rankingCobradores.length === 0 && <p className="text-gray-500 text-sm">Sin datos</p>}
              {rankingCobradores.map((r, i) => (
                <div key={i} className="flex items-center gap-3 py-2 border-b border-gray-800/50 last:border-0">
                  <span className="text-lg">{i === 0 ? '🥇' : i === 1 ? '🥈' : '🥉'}</span>
                  <div className="flex-1">
                    <p className="font-semibold text-sm">{r.username}</p>
                    <p className="text-xs text-gray-400">{r.cierres} cierres</p>
                  </div>
                  <span className="font-bold text-green-400">{fmt(r.total)}</span>
                </div>
              ))}
            </div>

            {/* Proyeccion 7 dias */}
            <div className="bg-gray-900/60 border border-gray-800 rounded-2xl p-4">
              <p className="text-sm text-gray-400 mb-3">Proyección Flujo (7 días)</p>
              <div className="flex items-end gap-1 h-32">
                {proyeccion7d.map((d, i) => {
                  const max = Math.max(...proyeccion7d.map(x => x.total), 1);
                  const h = (d.total / max) * 100;
                  return (
                    <div key={i} className="flex-1 flex flex-col items-center gap-1">
                      <div className="w-full bg-indigo-500/30 rounded-t-md relative" style={{ height: `${h}%`, minHeight: '4px' }}>
                        <div className="absolute inset-0 bg-indigo-500 rounded-t-md" style={{ height: `${h}%` }} />
                      </div>
                      <span className="text-xs text-gray-500">{i === 0 ? 'Hoy' : `+${i}`}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* RUTA */}
        {page === 'ruta' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold">🗺️ Hoja de Ruta</h2>
              <button onClick={optimizarRuta} className="text-sm text-blue-400 font-semibold active:scale-95 transition">📍 Reoptimizar</button>
            </div>
            {clientes.filter(c => c.saldo > 0).length === 0 && <div className="text-center py-12 text-gray-500"><p className="text-4xl mb-3">✅</p><p>Todos al día</p></div>}
            {clientes.filter(c => c.saldo > 0).map((cli, i) => {
              const sem = getSemafClient(cli);
              const fs = getFichasCliente(cli.id);
              const prox = fs.find(f => f.estado === 'activa');
              return (
                <div key={cli.id} className="bg-gray-900/60 border border-gray-800 rounded-2xl p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-indigo-500/20 rounded-xl flex items-center justify-center font-bold text-indigo-400">{i + 1}</div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm">{sem}</span>
                        <p className="font-semibold text-sm">{cli.nombre}</p>
                      </div>
                      <p className="text-xs text-gray-400 truncate">{cli.direccion}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-sm">{fmt(cli.saldo)}</p>
                      {prox && <p className="text-xs text-gray-500">Cuota: {fmt(prox.cuotaMonto)}</p>}
                    </div>
                  </div>
                  <div className="flex gap-2 mt-3">
                    <button onClick={() => waCliente(cli)} className="flex-1 bg-green-500/20 text-green-400 rounded-xl py-2 text-xs font-semibold active:scale-95 transition">💬 WhatsApp</button>
                    <button onClick={() => geoCliente(cli)} className="flex-1 bg-blue-500/20 text-blue-400 rounded-xl py-2 text-xs font-semibold active:scale-95 transition">📍 Maps</button>
                    <button onClick={() => { setMPago({ ficha: prox!, cliente: cli }); }} className="flex-1 bg-green-500 text-white rounded-xl py-2 text-xs font-semibold active:scale-95 transition">💵 Cobrar</button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* CONFIG */}
        {page === 'config' && (rol === 'super' || rol === 'admin') && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold">⚙️ Configuración</h2>
            <ConfigForm config={data.config} onSave={(c: any) => { save({ config: c }); audit('CONFIG_CAMBIO', 'Configuración modificada'); }} />
            <div className="rounded-3xl border border-indigo-500/20 bg-gradient-to-br from-gray-900/80 to-gray-800/70 p-5 shadow-xl shadow-indigo-900/20">
              <div className="flex items-center gap-2 mb-3">
                <span className="text-indigo-300 text-lg">ℹ️</span>
                <p className="font-bold text-indigo-200">Información del Sistema</p>
              </div>
              <div className="space-y-2 text-sm text-gray-300">
                <p><span className="text-gray-400">Software:</span> CobranzaPro EmD v1.0</p>
                <p><span className="text-gray-400">Programación y Arquitectura:</span> Emanuel Moreno Di Cesare.</p>
                <p><span className="text-gray-400">Contacto de Soporte:</span> emamoreno@icloud.com Wsp: 549-263-4340284</p>
              </div>
            </div>
            {(rol === 'super') && (
              <div className="space-y-2">
                <button onClick={() => setMAuditoria(true)} className="w-full bg-gray-800 border border-gray-700 text-gray-300 rounded-xl py-3 text-sm font-semibold active:scale-95 transition">📜 Ver Auditoría</button>
                <button onClick={() => { if (confirm('¿Exportar logs?')) { const csv = exportarAuditoria(); const blob = new Blob([csv], { type: 'text/csv' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `auditoria_${hoy()}.csv`; a.click(); } }} className="w-full bg-gray-800 border border-gray-700 text-gray-300 rounded-xl py-3 text-sm font-semibold active:scale-95 transition">📥 Exportar Auditoría CSV</button>
                <button onClick={() => doLogout()} className="w-full bg-red-500/20 border border-red-500/30 text-red-400 rounded-xl py-3 text-sm font-semibold active:scale-95 transition">🚪 Cerrar Sesión</button>
              </div>
            )}
            {rol === 'admin' && <button onClick={() => doLogout()} className="w-full bg-red-500/20 border border-red-500/30 text-red-400 rounded-xl py-3 text-sm font-semibold active:scale-95 transition">🚪 Cerrar Sesión</button>}
          </div>
        )}
        {user && (
          <footer className="pt-6 pb-2 text-center">
            <p className="text-[11px] leading-relaxed text-gray-500 tracking-wide">
              Desarrollado por Emanuel Moreno | Soluciones Tecnológicas © 2026
            </p>
          </footer>
        )}
      </main>

      {/* Tab Bar */}
      {user && (
        <nav className="fixed bottom-0 left-0 right-0 bg-gray-950/90 backdrop-blur-2xl border-t border-gray-800 z-50">
          <div className="flex">
            {[
              { k: 'dashboard', icon: '🏠', l: 'Inicio' },
              { k: 'clientes', icon: '👥', l: 'Clientes' },
              { k: 'fichas', icon: '📋', l: 'Fichas' },
              { k: 'ruta', icon: '🗺️', l: 'Ruta' },
              { k: 'gastos', icon: '💸', l: 'Gastos' },
              ...(rol !== 'cobrador' ? [{ k: 'kpis', icon: '📊', l: 'KPIs' }] : []),
              ...(rol !== 'cobrador' ? [{ k: 'config', icon: '⚙️', l: 'Ajustes' }] : []),
            ].map(t => (
              <button key={t.k} onClick={() => go(t.k)}
                className={`flex-1 flex flex-col items-center py-3 gap-0.5 transition-all ${page === t.k ? 'text-indigo-400' : 'text-gray-500'}`}>
                <span className="text-xl">{t.icon}</span>
                <span className="text-[10px] font-semibold">{t.l}</span>
              </button>
            ))}
          </div>
        </nav>
      )}

      {/* ====== MODALS ====== */}

      {/* Modal: Detalle Cliente */}
      {mDetalleCliente && (
        <Modal onClose={() => setMDetalleCliente(null)} title={`📋 ${mDetalleCliente.nombre}`}>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-gray-800/50 rounded-xl p-3">
                <p className="text-xs text-gray-400">Teléfono</p>
                <p className="font-semibold">{mDetalleCliente.telefono}</p>
              </div>
              <div className="bg-gray-800/50 rounded-xl p-3">
                <p className="text-xs text-gray-400">Dirección</p>
                <p className="font-semibold text-xs">{mDetalleCliente.direccion}</p>
              </div>
              <div className="bg-gray-800/50 rounded-xl p-3">
                <p className="text-xs text-gray-400">Saldo</p>
                <p className="font-bold text-indigo-400">{fmt(mDetalleCliente.saldo)}</p>
              </div>
              <div className="bg-gray-800/50 rounded-xl p-3">
                <p className="text-xs text-gray-400">Estado</p>
                <p className="font-semibold">{getSemafClient(mDetalleCliente)} {getStatusText(mDetalleCliente)}</p>
              </div>
            </div>
            {mDetalleCliente.notas && <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3"><p className="text-xs text-amber-400">Notas</p><p className="text-sm">{mDetalleCliente.notas}</p></div>}
            {mDetalleCliente.promesaFecha && <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-3"><p className="text-xs text-blue-400">Promesa de Pago</p><p className="text-sm">{mDetalleCliente.promesaFecha} — {mDetalleCliente.promesaPago}</p></div>}
            {/* Acciones */}
            <div className="flex gap-2">
              <button onClick={() => waCliente(mDetalleCliente)} className="flex-1 bg-green-500 text-white rounded-xl py-3 font-semibold text-sm active:scale-95 transition sticky bottom-0">💬 WhatsApp</button>
              <button onClick={() => geoCliente(mDetalleCliente)} className="flex-1 bg-blue-500 text-white rounded-xl py-3 font-semibold text-sm active:scale-95 transition sticky bottom-0">📍 Maps</button>
              {(rol === 'super' || rol === 'admin') && (
                <button onClick={() => { setMCliente(mDetalleCliente); setMDetalleCliente(null); }} className="flex-1 bg-amber-500 text-white rounded-xl py-3 font-semibold text-sm active:scale-95 transition sticky bottom-0">✏️ Editar</button>
              )}
            </div>
            {/* Fichas */}
            {getFichasCliente(mDetalleCliente.id).map(fic => (
              <div key={fic.id} className="bg-gray-800/50 rounded-xl p-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-semibold text-sm">{fic.tipo === 'prestamo' ? '💳' : '🛒'} {fic.tipo}</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${fic.estado === 'activa' ? 'bg-green-500/20 text-green-400' : 'bg-gray-600/20 text-gray-400'}`}>{fic.estado}</span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div><p className="text-gray-400">Total</p><p className="font-semibold">{fmt(fic.precioVenta)}</p></div>
                  <div><p className="text-gray-400">Saldo</p><p className="font-semibold text-indigo-400">{fmt(fic.saldo)}</p></div>
                  <div><p className="text-gray-400">Cuota</p><p className="font-semibold">{fmt(fic.cuotaMonto)}</p></div>
                </div>
                {fic.Mora > 0 && <p className="text-xs text-red-400 mt-2">⚠️ Mora acumulada: {fmt(fic.Mora)}</p>}
                <div className="flex gap-2 mt-3">
                  <button onClick={() => { setMPago({ ficha: fic, cliente: mDetalleCliente }); setMDetalleCliente(null); }} className="flex-1 bg-green-500 text-white rounded-xl py-2 text-xs font-semibold active:scale-95 transition">💵 Cobrar</button>
                  <button onClick={() => { setMNoPago({ ficha: fic, cliente: mDetalleCliente }); setMDetalleCliente(null); }} className="flex-1 bg-red-500/20 text-red-400 border border-red-500/30 rounded-xl py-2 text-xs font-semibold active:scale-95 transition">🚫 No Pago</button>
                </div>
              </div>
            ))}
          </div>
        </Modal>
      )}

      {/* Modal: Pago */}
      {mPago && (
        <Modal onClose={() => { setMPago(null); setGpsPos(null); }} title={`💵 Registrar Pago — ${mPago.cliente.nombre}`}>
          <div className="space-y-4">
            <div className="bg-gray-800/50 rounded-xl p-3 grid grid-cols-2 gap-3">
              <div><p className="text-xs text-gray-400">Cuota</p><p className="font-bold text-green-400">{fmt(mPago.ficha.cuotaMonto)}</p></div>
              <div><p className="text-xs text-gray-400">Saldo</p><p className="font-bold text-indigo-400">{fmt(mPago.ficha.saldo)}</p></div>
              {mPago.ficha.Mora > 0 && <div className="col-span-2"><p className="text-xs text-red-400">⚠️ Mora: {fmt(mPago.ficha.Mora)}</p></div>}
            </div>
            <PagoForm ficha={mPago.ficha} onPago={(monto, obs) => handlePago(mPago.ficha, mPago.cliente, monto, obs)} gpsLoading={gpsLoading} gpsPos={gpsPos} onCapturarGPS={() => capturarGPSAccion('pago')} />
          </div>
        </Modal>
      )}

      {/* Modal: No Pago */}
      {mNoPago && (
        <Modal onClose={() => { setMNoPago(null); setGpsPos(null); }} title={`🚫 No se pudo cobrar — ${mNoPago.cliente.nombre}`}>
          <NoPagoForm cliente={mNoPago.cliente} ficha={mNoPago.ficha} gpsLoading={gpsLoading} gpsPos={gpsPos} onCapturarGPS={() => capturarGPSAccion('nopago')} onSubmit={(motivo, obs, fechaPromesa) => handleNoPago(mNoPago.ficha, mNoPago.cliente, motivo, obs, fechaPromesa)} />
        </Modal>
      )}

      {/* Modal: Cliente */}
      {mCliente && (
        <Modal onClose={() => setMCliente(null)} title={mCliente.id ? '✏️ Editar Cliente' : '+ Nuevo Cliente'}>
          <ClienteForm cliente={mCliente} onSave={handleSaveCliente} onCancel={() => setMCliente(null)} onGeo={() => getGPS().then(p => { if (mCliente) setMCliente({ ...mCliente, lat: p.lat, lng: p.lng, coordenadaErr: undefined }); }).catch(() => setMCliente({ ...mCliente, coordenadaErr: 'No se pudo obtener GPS' }))} gpsLoading={gpsLoading} />
        </Modal>
      )}

      {/* Modal: Ficha */}
      {mFicha && (
        <Modal onClose={() => setMFicha(null)} title={mFicha.ficha ? '📋 Editar Ficha' : '+ Nueva Ficha'}>
          <FichaForm ficha={mFicha.ficha} cliente={mFicha.cliente} clientes={clientes} onSave={handleSaveFicha} onTab={tab} onSetTab={setTab} onEliminarPago={handleEliminarPago} />
        </Modal>
      )}

      {/* Modal: Gasto */}
      {mGasto && (
        <Modal onClose={() => setMGasto(null)} title="+ Registrar Gasto">
          <GastoForm onSave={handleSaveGasto} />
        </Modal>
      )}

      {/* Modal: Cierre Jornada */}
      {mJornada && (
        <Modal onClose={() => setMJornada(false)} title="🏁 Finalizar Jornada">
          <JornadaForm totalEsperado={kpis.totalCobradoHoy} gpsLoading={gpsLoading} gpsPos={gpsPos} onCapturarGPS={async () => { try { await getGPS(); } catch { alert('GPS obligatorio'); } }} onSubmit={(montoFisico, kmFin, novedades) => handleCierreJornada(montoFisico, kmFin, novedades)} />
        </Modal>
      )}

      {/* Modal: Ver Cierre */}
      {mCierre && (
        <Modal onClose={() => setMCierre(null)} title="✅ Cierre Registrado">
          <div className="space-y-3 text-center">
            <div className="text-5xl">{mCierre.diferencia === 0 ? '✅' : mCierre.diferencia! > 0 ? '💚' : '🚩'}</div>
            <p className="font-bold text-lg">Diferencia: {fmt(Math.abs(mCierre.diferencia!))}</p>
            <p className="text-gray-400 text-sm">{mCierre.diferencia! > 0 ? 'Sobrante' : mCierre.diferencia! < 0 ? 'Faltante' : 'Cuadrado'}</p>
          </div>
        </Modal>
      )}

      {/* Modal: Ruta Optimizada */}
      {mRuta && (
        <Modal onClose={() => setMRuta(false)} title="🗺️ Ruta Optimizada">
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {clientesOrdenados.length === 0 && <p className="text-center text-gray-400">Clientes sin coordenadas</p>}
            {clientesOrdenados.map((cli, i) => (
              <div key={cli.id} className="bg-gray-800/50 rounded-xl p-3 flex items-center gap-3">
                <div className="w-8 h-8 bg-indigo-500/20 rounded-lg flex items-center justify-center font-bold text-indigo-400">{i + 1}</div>
                <div className="flex-1">
                  <p className="font-semibold text-sm">{cli.nombre}</p>
                  <p className="text-xs text-gray-400">{cli.direccion}</p>
                </div>
                <span className="text-xs text-blue-400 font-mono">{cli.distancia?.toFixed(1)} km</span>
              </div>
            ))}
          </div>
        </Modal>
      )}

      {/* Modal: Auditoría */}
      {mAuditoria && (
        <Modal onClose={() => setMAuditoria(false)} title="📜 Logs de Auditoría">
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {getAuditoria().slice(0, 100).map(e => (
              <div key={e.id} className="bg-gray-800/50 rounded-lg p-3 text-xs">
                <div className="flex justify-between text-gray-500 mb-1">
                  <span>{e.fecha} {e.hora}</span>
                  <span className="text-indigo-400">{e.usuario}</span>
                </div>
                <p className="text-gray-300">{e.detalle}</p>
              </div>
            ))}
            {getAuditoria().length === 0 && <p className="text-center text-gray-500">Sin registros</p>}
          </div>
        </Modal>
      )}
    </div>
  );
}

// ==========================================
// SUB-COMPONENTS
// ==========================================

function LoginForm({ onLogin, loading }: { onLogin: (u: string, p: string) => void; loading: boolean }) {
  const [u, setU] = useState(''); const [p, setP] = useState('');
  return (
    <div className="space-y-3 bg-gray-900/75 rounded-3xl p-5 border border-gray-800 backdrop-blur-sm shadow-2xl">
      <div>
        <label className="text-xs text-gray-400 mb-1 block">Usuario</label>
        <input value={u} onChange={e => setU(e.target.value)} className="w-full bg-gray-900/80 border border-amber-400/20 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-amber-300/70 focus:ring-1 focus:ring-amber-300/40 transition" placeholder="Usuario" />
      </div>
      <div>
        <label className="text-xs text-gray-400 mb-1 block">Contraseña</label>
        <input type="password" value={p} onChange={e => setP(e.target.value)} className="w-full bg-gray-900/80 border border-amber-400/20 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-amber-300/70 focus:ring-1 focus:ring-amber-300/40 transition" placeholder="••••••••" />
      </div>
      <button onClick={() => u && p && onLogin(u, p)} disabled={loading}
        className="w-full bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 disabled:from-amber-500/50 disabled:to-yellow-500/50 text-gray-950 font-bold py-3 rounded-xl transition-all active:scale-[0.98] shadow-lg shadow-amber-500/20">
        {loading ? '⏳...' : 'Ingresar'}
      </button>
      <div className="grid grid-cols-3 gap-2 mt-3 text-xs text-gray-500">
        {[['super','super123'],['admin','admin123'],['cobrador','cobrador123']].map(([u,p]) => (
          <button key={u} onClick={() => { setU(u); setP(p); }} className="bg-gray-800/40 border border-gray-700/50 rounded-lg py-2 text-center hover:bg-gray-700/50 transition">{u}</button>
        ))}
      </div>
    </div>
  );
}

function Modal({ children, title, onClose }: { children: React.ReactNode; title: string; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm p-0 sm:p-4" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="bg-gray-900 border border-gray-700 rounded-t-3xl sm:rounded-2xl w-full max-w-lg max-h-[92vh] overflow-y-auto">
        <div className="sticky top-0 bg-gray-900 border-b border-gray-800 px-5 py-4 flex items-center justify-between z-10 rounded-t-3xl sm:rounded-t-2xl">
          <h2 className="font-bold text-base">{title}</h2>
          <button onClick={onClose} className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center text-gray-400 active:scale-90 transition">✕</button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

function PagoForm({ ficha, onPago, gpsLoading, gpsPos, onCapturarGPS }: { ficha: Ficha; onPago: (monto: number, obs: string) => void; gpsLoading: boolean; gpsPos: any; onCapturarGPS: () => void }) {
  const [monto, setMonto] = useState(ficha.cuotaMonto.toString()); const [obs, setObs] = useState('');
  const m = parseFloat(monto) || 0;
  const esParcial = m < ficha.cuotaMonto && m > 0;
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <button onClick={onCapturarGPS} disabled={gpsLoading} className={`text-xs px-3 py-2 rounded-xl font-semibold active:scale-95 transition ${gpsPos ? 'bg-green-500/20 text-green-400' : 'bg-gray-800 text-gray-400'}`}>
          {gpsLoading ? '⏳ GPS...' : gpsPos ? '✅ GPS OK' : '📍 Capturar GPS'}
        </button>
        {gpsPos && <span className="text-xs text-gray-500">{gpsPos.lat.toFixed(4)}, {gpsPos.lng.toFixed(4)}</span>}
      </div>
      <div>
        <label className="text-xs text-gray-400 block mb-1">Monto a registrar</label>
        <input type="number" value={monto} onChange={e => setMonto(e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white text-xl font-bold focus:outline-none focus:border-indigo-500" />
        {esParcial && <p className="text-xs text-orange-400 mt-1">⚠️ Pago parcial. Faltante de {fmt(ficha.cuotaMonto - m)} se arrastrará a próxima cuota</p>}
      </div>
      <div>
        <label className="text-xs text-gray-400 block mb-1">Observaciones (opcional)</label>
        <textarea value={obs} onChange={e => setObs(e.target.value)} rows={2} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-indigo-500 resize-none" placeholder="Ej: Dejó en sobre bajo la puerta" />
      </div>
      <div className="flex gap-3 sticky bottom-0 bg-gray-900 pt-2">
        <button onClick={() => onPago(m, obs)} disabled={!gpsPos && false} className="flex-1 bg-green-500 text-white font-bold py-3 rounded-xl active:scale-95 transition-all shadow-lg">💵 Confirmar Pago</button>
      </div>
    </div>
  );
}

function NoPagoForm({ gpsLoading, gpsPos, onCapturarGPS, onSubmit }: {
  cliente: Cliente; ficha: Ficha; gpsLoading: boolean; gpsPos: any; onCapturarGPS: () => void;
  onSubmit: (motivo: string, obs: string, fechaPromesa: string) => void;
}) {
  const [motivo, setMotivo] = useState(''); const [obs, setObs] = useState(''); const [fechaPromesa, setFechaPromesa] = useState('');
  const motivos = [{ k: 'no_domicilio', l: '🚪 No estaba en domicilio' }, { k: 'sin_dinero', l: '💸 No tenía el dinero' }, { k: 'local_cerrado', l: '🔒 Local cerrado' }, { k: 'promesa_pago', l: '📅 Promesa de pago' }];
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <button onClick={onCapturarGPS} disabled={gpsLoading} className={`text-xs px-3 py-2 rounded-xl font-semibold active:scale-95 transition ${gpsPos ? 'bg-green-500/20 text-green-400' : 'bg-gray-800 text-gray-400'}`}>
          {gpsLoading ? '⏳ GPS...' : gpsPos ? '✅ GPS OK' : '📍 Capturar GPS (obligatorio)'}
        </button>
        {!gpsPos && <span className="text-xs text-red-400">GPS requerido</span>}
      </div>
      <div className="space-y-2">
        {motivos.map(m => (
          <button key={m.k} onClick={() => setMotivo(m.k)} className={`w-full text-left px-4 py-3 rounded-xl text-sm font-semibold transition-all ${motivo === m.k ? 'bg-indigo-500 text-white' : 'bg-gray-800 text-gray-300'}`}>
            {m.l}
          </button>
        ))}
      </div>
      {motivo === 'promesa_pago' && (
        <div>
          <label className="text-xs text-gray-400 block mb-1">Nueva fecha de visita</label>
          <input type="date" value={fechaPromesa} onChange={e => setFechaPromesa(e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500" />
        </div>
      )}
      <div>
        <label className="text-xs text-gray-400 block mb-1">Observaciones</label>
        <textarea value={obs} onChange={e => setObs(e.target.value)} rows={2} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-indigo-500 resize-none" />
      </div>
      <div className="flex gap-3 sticky bottom-0 bg-gray-900 pt-2">
        <button onClick={() => { if (!gpsPos) { alert('GPS obligatorio'); return; } if (!motivo) { alert('Seleccioná un motivo'); return; } onSubmit(motivo, obs, fechaPromesa); }} className="flex-1 bg-red-500 text-white font-bold py-3 rounded-xl active:scale-95 transition-all">🚫 Confirmar No Pago</button>
      </div>
    </div>
  );
}

function ClienteForm({ cliente, onSave, onCancel, onGeo, gpsLoading }: { cliente: Partial<Cliente>; onSave: (c: Partial<Cliente>) => void; onCancel: () => void; onGeo: () => void; gpsLoading: boolean }) {
  const [f, setF] = useState<Partial<Cliente>>(cliente);
  const s = (k: keyof Cliente, v: any) => setF({ ...f, [k]: v });
  return (
    <div className="space-y-4">
      <div><label className="text-xs text-gray-400 block mb-1">Nombre *</label><input value={f.nombre || ''} onChange={e => s('nombre', e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500" placeholder="Nombre completo" /></div>
      <div><label className="text-xs text-gray-400 block mb-1">Teléfono *</label><input value={f.telefono || ''} onChange={e => s('telefono', e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500" placeholder="549xxxxxxxxx" /></div>
      <div><label className="text-xs text-gray-400 block mb-1">Dirección</label><input value={f.direccion || ''} onChange={e => s('direccion', e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500" placeholder="Dirección" /></div>
      <div className="flex gap-2">
        <button onClick={onGeo} disabled={gpsLoading} className="flex-1 bg-blue-500/20 text-blue-400 border border-blue-500/30 rounded-xl py-3 text-sm font-semibold active:scale-95 transition">{gpsLoading ? '⏳...' : '📍 Capturar GPS'}</button>
        {f.lat && <span className="text-xs text-gray-500 self-center">{f.lat?.toFixed(4)}, {f.lng?.toFixed(4)}</span>}
      </div>
      {f.coordenadaErr && <p className="text-xs text-red-400">{f.coordenadaErr}</p>}
      <div><label className="text-xs text-gray-400 block mb-1">Cuota Semanal</label><input type="number" value={f.quota || ''} onChange={e => s('quota', parseFloat(e.target.value))} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500" /></div>
      <div><label className="text-xs text-gray-400 block mb-1">Frecuencia</label>
        <select value={f.frecuencia || 'semanal'} onChange={e => s('frecuencia', e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500">
          <option value="diaria">Diaria</option><option value="semanal">Semanal</option><option value="quincenal">Quincenal</option><option value="mensual">Mensual</option>
        </select>
      </div>
      <div className="flex gap-3 sticky bottom-0 bg-gray-900 pt-2">
        <button onClick={() => onSave(f)} className="flex-1 bg-indigo-500 text-white font-bold py-3 rounded-xl active:scale-95 transition-all">💾 Guardar</button>
        <button onClick={() => {
          onCancel();
        }} className="flex-1 bg-gray-700 text-white font-bold py-3 rounded-xl active:scale-95 transition-all">Cancelar</button>
      </div>
    </div>
  );
}

function FichaForm({ ficha, cliente, clientes, onSave, onTab, onSetTab, onEliminarPago }: { ficha?: Ficha; cliente: Cliente | null; clientes: Cliente[]; onSave: (f: Partial<Ficha>) => void; onTab: number; onSetTab: (t: number) => void; onEliminarPago: (ficha: Ficha, idx: number) => void }) {
  const [f, setF] = useState<Partial<Ficha>>(ficha || { clienteId: cliente?.id || '', tipo: 'prestamo', montoTotal: 0, cuotas: 4, costo: 0 });
  const s = (k: keyof Ficha, v: any) => setF({ ...f, [k]: v });
  return (
    <div className="space-y-4">
      <div className="flex bg-gray-800 rounded-xl p-1 gap-1">
        {['Datos', 'Cara B'].map((t, i) => (
          <button key={i} onClick={() => onSetTab(i)} className={`flex-1 py-2 rounded-lg text-xs font-semibold transition-all ${onTab === i ? 'bg-indigo-500 text-white' : 'text-gray-400'}`}>{t}</button>
        ))}
      </div>
      {onTab === 0 && (
        <div className="space-y-4">
          {!ficha && (<div><label className="text-xs text-gray-400 block mb-1">Cliente</label><select id="selCliente" value={f.clienteId || ''} onChange={e => s('clienteId', e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500"><option value="">Seleccionar...</option>{clientes.map(c => <option key={c.id} value={c.id}>{c.nombre}</option>)}</select></div>)}
          <div><label className="text-xs text-gray-400 block mb-1">Tipo</label><select value={f.tipo || 'prestamo'} onChange={e => s('tipo', e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500"><option value="prestamo">💳 Préstamo</option><option value="venta">🛒 Venta</option></select></div>
          <div><label className="text-xs text-gray-400 block mb-1">Monto Total</label><input type="number" value={f.montoTotal || ''} onChange={e => s('montoTotal', parseFloat(e.target.value))} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500" /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="text-xs text-gray-400 block mb-1">Costo</label><input type="number" value={f.costo || ''} onChange={e => s('costo', parseFloat(e.target.value))} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500" /></div>
            <div><label className="text-xs text-gray-400 block mb-1">Cuotas</label><input type="number" value={f.cuotas || 4} onChange={e => s('cuotas', parseInt(e.target.value))} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500" /></div>
          </div>
          {f.montoTotal && f.cuotas && <div className="bg-indigo-500/10 border border-indigo-500/30 rounded-xl p-3 text-center"><p className="text-xs text-indigo-400">Precio Venta</p><p className="text-2xl font-bold text-indigo-300">${((f.montoTotal || 0) * 1.3).toLocaleString('es-AR', { minimumFractionDigits: 0 })}</p><p className="text-xs text-indigo-400/60">Ganancia: ${((f.montoTotal || 0) * 0.3).toLocaleString('es-AR')}</p></div>}
        </div>
      )}
      {onTab === 1 && ficha && (
        <div className="space-y-3">
          <p className="text-sm text-gray-400 text-center">Grilla de Cobros - {cliente?.nombre}</p>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-gray-800">
                  <th className="p-2 text-left">Día</th><th className="p-2 text-left">Fecha</th><th className="p-2 text-center">Estado</th><th className="p-2 text-right">Monto</th><th className="p-2"></th>
                </tr>
              </thead>
              <tbody>
                {Array.from({ length: ficha.cuotas }, (_, i) => {
                  const p = ficha.pagos[i];
                  const fecha = addDias(ficha.fecha, (i + 1) * 7);
                  return (
                    <tr key={i} className={`border-t border-gray-800 ${p?.tipo === 'completo' ? 'bg-green-500/5' : p?.tipo === 'parcial' ? 'bg-orange-500/5' : diffDias(hoy(), fecha) > 0 ? 'bg-red-500/5' : ''}`}>
                      <td className="p-2">{i + 1}</td>
                      <td className="p-2">{fecha}</td>
                      <td className="p-2 text-center">{p?.tipo === 'completo' ? '✅' : p?.tipo === 'parcial' ? '½' : diffDias(hoy(), fecha) > 0 ? '🚩' : '⏳'}</td>
                      <td className="p-2 text-right font-semibold">{p ? `${fmt(p.monto)}` : fmt(ficha.cuotaMonto)}</td>
                      <td className="p-2">{p && <button type="button" onClick={() => onEliminarPago(ficha, i)} className="text-red-400 text-xs">✕</button>}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
      {onTab === 0 && (
        <div className="flex gap-3 sticky bottom-0 bg-gray-900 pt-2">
          <button onClick={() => onSave(f)} className="flex-1 bg-indigo-500 text-white font-bold py-3 rounded-xl active:scale-95 transition-all">💾 Guardar</button>
        </div>
      )}
    </div>
  );
}

function GastoForm({ onSave }: { onSave: (g: Partial<Gasto>) => void }) {
  const [cat, setCat] = useState('Combustible'); const [monto, setMonto] = useState(''); const [nota, setNota] = useState('');
  return (
    <div className="space-y-4">
      <div><label className="text-xs text-gray-400 block mb-1">Categoría</label>
        <select value={cat} onChange={e => setCat(e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500">
          {['Combustible', 'Comida', 'Reparaciones', 'Otros'].map(c => <option key={c}>{c}</option>)}
        </select>
      </div>
      <div><label className="text-xs text-gray-400 block mb-1">Monto</label><input type="number" value={monto} onChange={e => setMonto(e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500" placeholder="$0.00" /></div>
      <div><label className="text-xs text-gray-400 block mb-1">Nota</label><input value={nota} onChange={e => setNota(e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500" placeholder="Descripción..." /></div>
      <div className="flex gap-3 sticky bottom-0 bg-gray-900 pt-2">
        <button onClick={() => { if (!monto) return; onSave({ categoria: cat, monto: parseFloat(monto), nota }); }} className="flex-1 bg-orange-500 text-white font-bold py-3 rounded-xl active:scale-95 transition-all">💾 Registrar Gasto</button>
      </div>
    </div>
  );
}

function JornadaForm({ totalEsperado, gpsLoading, gpsPos, onCapturarGPS, onSubmit }: { totalEsperado: number; gpsLoading: boolean; gpsPos: any; onCapturarGPS: () => void; onSubmit: (montoFisico: number, kmFin?: number, novedades?: string) => void }) {
  const [montoFisico, setMontoFisico] = useState(totalEsperado.toString()); const [kmFin, setKmFin] = useState(''); const [novedades, setNovedades] = useState('');
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <button onClick={onCapturarGPS} disabled={gpsLoading} className={`text-xs px-3 py-2 rounded-xl font-semibold active:scale-95 transition ${gpsPos ? 'bg-green-500/20 text-green-400' : 'bg-gray-800 text-gray-400'}`}>
          {gpsLoading ? '⏳ GPS...' : gpsPos ? '✅ GPS OK' : '📍 Capturar GPS'}
        </button>
        {gpsPos && <span className="text-xs text-gray-500">{gpsPos.lat.toFixed(4)}, {gpsPos.lng.toFixed(4)}</span>}
      </div>
      <div className="bg-indigo-500/10 border border-indigo-500/30 rounded-xl p-4 text-center">
        <p className="text-xs text-indigo-400">Total en Sistema</p>
        <p className="text-3xl font-bold text-indigo-300">{fmt(totalEsperado)}</p>
      </div>
      <div><label className="text-xs text-gray-400 block mb-1">Efectivo Físico en Mano *</label><input type="number" value={montoFisico} onChange={e => setMontoFisico(e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white text-xl font-bold focus:outline-none focus:border-indigo-500" /></div>
      <div><label className="text-xs text-gray-400 block mb-1">Kilometraje Final (opcional)</label><input type="number" value={kmFin} onChange={e => setKmFin(e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500" /></div>
      <div><label className="text-xs text-gray-400 block mb-1">Novedades</label><textarea value={novedades} onChange={e => setNovedades(e.target.value)} rows={2} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-indigo-500 resize-none" /></div>
      {parseFloat(montoFisico) !== totalEsperado && (
        <div className={`rounded-xl p-3 text-center ${parseFloat(montoFisico) > totalEsperado ? 'bg-green-500/10 border border-green-500/30' : 'bg-red-500/10 border border-red-500/30'}`}>
          <p className={`font-bold ${parseFloat(montoFisico) > totalEsperado ? 'text-green-400' : 'text-red-400'}`}>
            {parseFloat(montoFisico) > totalEsperado ? '💚 Sobrante' : '🚩 Faltante'}: {fmt(Math.abs(parseFloat(montoFisico) - totalEsperado))}
          </p>
        </div>
      )}
      <div className="flex gap-3 sticky bottom-0 bg-gray-900 pt-2">
        <button onClick={() => { if (!gpsPos) { alert('GPS obligatorio'); return; } if (!montoFisico) return; onSubmit(parseFloat(montoFisico), kmFin ? parseFloat(kmFin) : undefined, novedades); }} className="flex-1 bg-indigo-500 text-white font-bold py-3 rounded-xl active:scale-95 transition-all shadow-lg shadow-indigo-500/30">🏁 Finalizar y Enviar Reporte</button>
      </div>
    </div>
  );
}

function SplashScreen({ elapsedMs }: { elapsedMs: number }) {
  const phase2 = elapsedMs >= 1500;
  const phase3 = elapsedMs >= 2000;
  const phase4 = elapsedMs >= 2800;
  return (
    <div className={`fixed inset-0 z-50 bg-gray-950 flex items-center justify-center transition-opacity duration-200 ${phase4 ? 'opacity-0' : 'opacity-100'}`}>
      <style>{`
        @keyframes coinSpin {
          0% { transform: rotateY(0deg) scale(0.92); }
          75% { transform: rotateY(1800deg) scale(1); }
          100% { transform: rotateY(2160deg) scale(1); }
        }
        @keyframes coinSheen {
          0%, 100% { opacity: 0.35; transform: translateX(-140%); }
          50% { opacity: 0.9; transform: translateX(140%); }
        }
        @keyframes symbolFlare {
          0% { opacity: 0; transform: translateX(-140%) skewX(-15deg); }
          50% { opacity: 1; }
          100% { opacity: 0; transform: translateX(180%) skewX(-15deg); }
        }
        @keyframes textSweep {
          0% { background-position: -220% 0; opacity: 0.2; }
          25% { opacity: 1; }
          100% { background-position: 220% 0; opacity: 1; }
        }
      `}</style>

      <div className="relative flex flex-col items-center justify-center">
        <div className="relative w-28 h-28 [perspective:900px]">
          <div
            className={`absolute inset-0 rounded-full border border-amber-300/50 bg-gradient-to-br from-amber-200 via-yellow-400 to-amber-600 shadow-[0_0_35px_rgba(245,158,11,0.35)] overflow-hidden transition-all duration-500 ${phase2 ? 'opacity-0 scale-95' : 'opacity-100'}`}
            style={{ animation: phase2 ? 'none' : 'coinSpin 1.5s cubic-bezier(.2,.7,.2,1) forwards' }}
          >
            <div className="absolute inset-0 rounded-full" style={{ background: 'linear-gradient(120deg, rgba(255,255,255,0) 35%, rgba(255,255,255,0.55) 50%, rgba(255,255,255,0) 65%)', animation: 'coinSheen 0.9s ease-in-out infinite' }} />
            <div className="absolute inset-3 rounded-full border border-amber-100/40" />
          </div>

          <div className={`absolute inset-0 flex items-center justify-center transition-all duration-500 ${phase2 ? 'opacity-100 scale-100' : 'opacity-0 scale-75'}`}>
            <span className="text-7xl font-semibold leading-none text-transparent bg-clip-text bg-gradient-to-b from-yellow-200 via-amber-400 to-amber-600 drop-shadow-[0_0_14px_rgba(251,191,36,0.45)]">$</span>
            {phase2 && <span className="absolute inset-0 pointer-events-none" style={{ background: 'linear-gradient(100deg, transparent 30%, rgba(255,255,255,0.9) 50%, transparent 70%)', animation: 'symbolFlare 0.45s ease-out 1' }} />}
          </div>
        </div>

        <div className={`mt-6 transition-all duration-300 ${phase3 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'}`}>
          <p
            className="font-medium tracking-widest text-base text-transparent bg-clip-text"
            style={{
              backgroundImage: 'linear-gradient(100deg, #6b7280 20%, #ffffff 45%, #e5e7eb 55%, #6b7280 80%)',
              backgroundSize: '220% 100%',
              animation: phase3 ? 'textSweep 0.8s ease-out 1 forwards' : 'none',
            }}
          >
            EmD SOFTWARE
          </p>
        </div>
      </div>
    </div>
  );
}

function ConfigForm({ config, onSave }: { config: Config; onSave: (c: Config) => void }) {
  const [f, setF] = useState(config);
  const s = (k: keyof Config, v: any) => setF({ ...f, [k]: v });
  return (
    <div className="space-y-4">
      <div><label className="text-xs text-gray-400 block mb-1">Nombre Empresa</label><input value={f.nombreEmpresa} onChange={e => s('nombreEmpresa', e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500" /></div>
      <div><label className="text-xs text-gray-400 block mb-1">Teléfono</label><input value={f.telefonoEmpresa} onChange={e => s('telefonoEmpresa', e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500" /></div>
      <div><label className="text-xs text-gray-400 block mb-1">Dirección</label><input value={f.direccionEmpresa} onChange={e => s('direccionEmpresa', e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500" /></div>
      <div><label className="text-xs text-gray-400 block mb-1">RUC / CUIT</label><input value={f.ruc} onChange={e => s('ruc', e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500" /></div>
      <div><label className="text-xs text-gray-400 block mb-1">% Mora (diario)</label><input type="number" value={f.moraPorciento} onChange={e => s('moraPorciento', parseFloat(e.target.value))} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500" /></div>
      <div><label className="text-xs text-gray-400 block mb-1">WhatsApp Admin (sin 0, con área)</label><input value={f.numeroWhatsappAdmin} onChange={e => s('numeroWhatsappAdmin', e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500" placeholder="Ej: 1134567890" /></div>
      <div className="flex gap-3 sticky bottom-0 bg-gray-900 pt-2">
        <button onClick={() => onSave(f)} className="flex-1 bg-indigo-500 text-white font-bold py-3 rounded-xl active:scale-95 transition-all">💾 Guardar</button>
      </div>
    </div>
  );
}
